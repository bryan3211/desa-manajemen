@extends('layouts.dashboard')
@section('title', 'Isi Biodata')
@section('content')
    <div class="pc-content">
        <h2>Isi Biodata</h2>
    </div>
    <!-- Form biodata siswa -->
@endsection
