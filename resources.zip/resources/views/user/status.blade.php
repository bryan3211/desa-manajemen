@extends('layouts.dashboard')
@section('title', 'Status Seleksi')
@section('content')
    <div class="pc-content">
        <h2>Status Seleksi</h2>
        <!-- Tabel status seleksi, pengumuman -->
    </div>
@endsection
