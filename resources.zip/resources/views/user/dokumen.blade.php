@extends('layouts.dashboard')
@section('title', 'Upload Dokumen')
@section('content')
    <div class="pc-content">
        <h2>Upload Dokumen</h2>
    </div>
    <!-- Form upload dokumen, status verifikasi -->
@endsection
