@extends('layouts.dashboard')
@section('title', 'Daftar Ulang')
@section('content')
    <div class="pc-content">
        <h2>Daftar Ulang</h2>
    </div>
    <!-- Form konfirmasi daftar ulang -->
@endsection
