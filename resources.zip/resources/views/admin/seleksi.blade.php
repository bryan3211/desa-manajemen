@extends('layouts.dashboard')
@section('title', 'Seleksi')
@section('content')
    <div class="pc-content">
        <h2>Seleksi</h2>
    </div>
    <!-- Tabel nilai rapor, hasil tes, status seleksi -->
@endsection
