@extends('layouts.dashboard')
@section('title', 'Laporan')
@section('content')
    <div class="pc-content">
        <h2>Laporan Siswa Baru</h2>
    </div>
    <!-- Export data, rekap siswa diterima -->
@endsection
