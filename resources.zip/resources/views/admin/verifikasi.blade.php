@extends('layouts.dashboard')
@section('title', 'Verifikasi Berkas')
@section('content')
    <div class="pc-content">
        <h2>Verifikasi Berkas</h2>
    </div>
    <!-- Tabel dokumen pendaftar, tombol validasi/revisi -->
@endsection
