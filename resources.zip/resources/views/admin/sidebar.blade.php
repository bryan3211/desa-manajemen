<li class="pc-item">
    <a href="{{ route('admin.verifikasi') }}" class="pc-link">
        <span class="pc-micon"><i class="ti ti-file-check"></i>
        </span><span class="pc-mtext">Verifikasi Berkas</span></a>
</li>
<li class="pc-item">
    <a href="{{ route('admin.biodata.index') }}" class="pc-link">
        <span class="pc-micon"><i class="ti ti-id-badge"></i>
        </span><span class="pc-mtext">Kelola Biodata</span></a>
</li>
<li class="pc-item">
    <a href="{{ route('admin.pengaduan.index') }}" class="pc-link">
        <span class="pc-micon"><i class="ti ti-alert-circle"></i>
        </span><span class="pc-mtext">Kelola Pengaduan</span></a>
</li>
<li class="pc-item">
    <a href="{{ route('admin.penduduk.index') }}" class="pc-link">
        <span class="pc-micon"><i class="ti ti-users"></i></span>
        <span class="pc-mtext">Data Penduduk</span>
    </a>
</li>