@extends('layouts.dashboard')
@section('title', 'Pengumuman')
@section('content')
    <div class="pc-content">
        <h2>Pengumuman Hasil Seleksi</h2>
    </div>
    <!-- Tabel siswa diterima/tidak, publish hasil -->
@endsection
